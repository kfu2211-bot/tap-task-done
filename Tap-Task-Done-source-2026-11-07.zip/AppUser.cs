namespace tts.Data;

public sealed class AppUser
{
    public int Id { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? Username { get; set; }
    public string? Role { get; set; }
    public byte[]? PasswordHash { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public byte[]? ProfilePicture { get; set; }
}
