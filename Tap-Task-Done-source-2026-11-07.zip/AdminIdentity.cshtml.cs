using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using tts.Data;
namespace tts.Pages;
[Authorize(Policy = "AdminOnly")]
public class AdminIdentityModel(ApplicationDbContext db, IDataProtectionProvider protection, IdentityVerificationAvailability availability) : PageModel
{
    public record Item(long Id, string Name, string Status, string IdLast4, DateTime CreatedAt, bool HasCertification, bool HasSupporting) { public bool HasSelfie { get; init; } public string? GovernmentType { get; init; } }
    public List<Item> Items { get; private set; } = [];
    public bool DatabaseUnavailable { get; private set; }
    public Dictionary<long, string> DocumentTypes { get; private set; } = [];
    public bool ReviewEnabled => availability.Enabled;
    [BindProperty(SupportsGet = true)] public bool Embedded { get; set; }
    [TempData(Key = "AdminIdentity.Notice")] public string? Notice { get; set; }
    private int AdminId => int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id) ? id : 0;
    public async Task<IActionResult> OnGetAsync(CancellationToken ct)
    {
        Response.Headers.CacheControl = "no-store";
        if (!availability.Enabled) Notice = "Document review is paused until secure document storage is configured. Existing requests are listed below.";
        try { Items = await (from r in db.IdentityRequests.AsNoTracking() join u in db.Users.AsNoTracking() on r.UserId equals u.Id orderby r.Id descending select new Item(r.Id, ((u.FirstName ?? "") + " " + (u.LastName ?? "")).Trim(), r.Status, r.IdLast4, r.CreatedAt, r.Certification != null, r.SupportingDocument != null)).Take(100).ToListAsync(ct); }
        catch (MySqlConnector.MySqlException ex) when (ex.Number == 1146 && !availability.Enabled)
        { Notice = "No verification requests have been set up. Document submissions and review are paused until secure document storage is configured."; }
        catch (Exception ex) when (ex is MySqlConnector.MySqlException or InvalidOperationException) { DatabaseUnavailable = true; Notice = "Verification requests could not be loaded. Please check the database setup and try again."; }
        if (Items.Count > 0)
        {
            try
            {
                var ids = Items.Select(x => x.Id).ToList();
                var types = await db.IdentityResources.AsNoTracking().Where(x => ids.Contains(x.IdentityRequestId) && x.Kind == "document-type").Select(x => new { x.IdentityRequestId, x.EncryptedData }).ToListAsync(ct);
                foreach (var type in types)
                {
                    try { DocumentTypes[type.IdentityRequestId] = System.Text.Encoding.UTF8.GetString(protection.CreateProtector("tts.identity.documents.v1").Unprotect(type.EncryptedData)); }
                    catch (System.Security.Cryptography.CryptographicException) { DocumentTypes[type.IdentityRequestId] = "Unavailable — inspect the submitted document"; }
                }
                var resources = await db.IdentityResources.AsNoTracking().Where(x => ids.Contains(x.IdentityRequestId))
                    .Select(x => new { x.IdentityRequestId, x.Kind, x.ContentType }).ToListAsync(ct);
                Items = Items.Select(item => item with {
                    HasSelfie = resources.Any(x => x.IdentityRequestId == item.Id && x.Kind == "selfie"),
                    GovernmentType = resources.FirstOrDefault(x => x.IdentityRequestId == item.Id && x.Kind == "id")?.ContentType,
                    HasCertification = item.HasCertification || resources.Any(x => x.IdentityRequestId == item.Id && x.Kind == "certification"),
                    HasSupporting = item.HasSupporting || resources.Any(x => x.IdentityRequestId == item.Id && x.Kind == "supporting")
                }).ToList();
            }
            catch (Exception ex) when (ex is MySqlConnector.MySqlException or InvalidOperationException)
            { Notice = "Requests are shown, but supplemental documents could not be loaded. Please check document storage before reviewing attachments."; }
        }
        return Page();
    }
    public async Task<IActionResult> OnPostReviewAsync(long id, string? decision, string? note, bool matchConfirmed, CancellationToken ct)
    {
        if (!availability.Enabled) return NotFound(); note = (note ?? "").Trim();
        if (AdminId <= 0 || decision is not ("approved" or "rejected" or "resubmit") || note.Length > 500 || (decision != "approved" && string.IsNullOrWhiteSpace(note))) { Notice = "Add a reason when rejecting or requesting a new submission (up to 500 characters)."; return RedirectToPage(new { embedded = Embedded }); }
        if (decision == "approved" && !matchConfirmed) { Notice = "Compare the ID and selfie, then confirm your manual review before approving."; return RedirectToPage(new { embedded = Embedded }); }
        if (decision == "approved" && !await db.IdentityResources.AnyAsync(x => x.IdentityRequestId == id && x.Kind == "selfie", ct)) { Notice = "This request has no selfie. Request a new submission with a selfie before approving."; return RedirectToPage(new { embedded = Embedded }); }
        var changed = await db.IdentityRequests.Where(x => x.Id == id && x.Status == "pending").ExecuteUpdateAsync(s => s.SetProperty(x => x.Status, decision).SetProperty(x => x.ReviewNote, note).SetProperty(x => x.ReviewedAt, DateTime.UtcNow).SetProperty(x => x.ReviewReadAt, (DateTime?)null).SetProperty(x => x.ReviewedById, AdminId), ct);
        Notice = changed == 1 ? "Decision saved." : "Request was already reviewed or is unavailable."; return RedirectToPage(new { embedded = Embedded });
    }
    public async Task<IActionResult> OnGetDocumentAsync(long id, string kind, CancellationToken ct)
    {
        if (!availability.Enabled || kind is not ("id" or "certification" or "supporting" or "selfie")) return NotFound();
        var resource = await db.IdentityResources.AsNoTracking().Where(x => x.IdentityRequestId == id && x.Kind == kind).Select(x => new { x.EncryptedData, x.ContentType }).SingleOrDefaultAsync(ct);
        byte[]? data = resource?.EncryptedData; string? type = resource?.ContentType;
        if (resource is null) {
            var r = await db.IdentityRequests.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id, ct); if (r is null) return NotFound();
            (data, type) = kind switch { "id" => (r.GovernmentId, r.GovernmentType), "certification" => (r.Certification, r.CertificationType), "supporting" => (r.SupportingDocument, r.SupportingType), _ => (null, null) };
        }
        if (data is null || type is null) return NotFound();
        try { var bytes = protection.CreateProtector("tts.identity.documents.v1").Unprotect(data); Response.Headers.CacheControl = "no-store"; Response.Headers.XContentTypeOptions = "nosniff"; if (type is "image/jpeg" or "image/png") return File(bytes, type); return File(bytes, "application/octet-stream", "verification-document.pdf"); }
        catch (System.Security.Cryptography.CryptographicException) { return StatusCode(503); }
    }
}
