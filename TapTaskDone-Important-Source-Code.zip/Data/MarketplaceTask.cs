namespace tts.Data;

public sealed class MarketplaceTask
{
    public long Id { get; set; }
    public int ClientId { get; set; }
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public string Category { get; set; } = "";
    public string? SpecificService { get; set; }
    public string CategoryDisplay => string.IsNullOrWhiteSpace(SpecificService) ? Category
        : Category + " · " + (SpecificService == ServiceCatalog.CustomOption ? "Other " + Category.ToLowerInvariant() : SpecificService);
    public string? ArrivalInstructions { get; set; }
    public string Location { get; set; } = "";
    public decimal Budget { get; set; }
    public decimal? BudgetMaximum { get; set; }
    public int? PostDurationDays { get; set; }
    public DateTime? PostExpiresUtc { get; set; }
    public string BudgetDisplay => BudgetMaximum.HasValue && BudgetMaximum.Value != Budget
        ? $"₱{Budget:N2} – ₱{BudgetMaximum.Value:N2}" : $"₱{Budget:#,##0.##}";
    public int? EstimatedMinutes { get; set; }
    public string? JobType { get; set; }
    public DateTime? WorkEndUtc { get; set; }
    public string JobTypeDisplay => JobTypes.Label(JobType);
    public string DurationDisplay => JobDuration.Display(EstimatedMinutes);
    public string ScheduleText { get; set; } = "";
    public string Status { get; set; } = "pending-confirmation";
    public bool IsPrivate { get; set; }
    public string? CancellationReason { get; set; }
    public DateTime CreatedAt { get; set; }
}

public sealed class MarketplaceOffer
{
    public long Id { get; set; }
    public long TaskId { get; set; }
    public int FreelancerId { get; set; }
    public decimal Price { get; set; }
    public string Message { get; set; } = "";
    public string Status { get; set; } = "pending";
    public string? WithdrawalReason { get; set; }
    public DateTime CreatedAt { get; set; }
}
