using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using tts.Data;
using System.Security.Claims;

namespace tts.Pages
{
    public class FindPostModel(ApplicationDbContext db, ILogger<FindPostModel> logger) : PageModel
    {
        public record Provider(int Id, string Name, string Service, string Location, int? Rate, int? RateMaximum, string SavedAvailability, string? ServiceSpecialties)
        {
            public string Availability { get; init; } = SavedAvailability;
        }
        public record RatingSummary(double Average, int Count);
        public List<Provider> Providers { get; private set; } = [];
        public Dictionary<int, RatingSummary> Ratings { get; private set; } = [];
        public bool RatingsUnavailable { get; private set; }
        public List<MarketTasksModel.TaskItem> OpenTasks { get; private set; } = [];
        public List<MarketTasksModel.OfferItem> Offers { get; private set; } = [];
        public Dictionary<long, string> OfferTaskTitles { get; private set; } = [];
        public string[] MatchingJobIds { get; private set; } = [];
        public string WorkRole { get; private set; } = "client";
        public bool WorkLocked { get; private set; }
        [Microsoft.AspNetCore.Mvc.TempData] public string? Notice { get; set; }
        public bool DirectoryUnavailable { get; private set; }
        public bool IdentityApproved { get; private set; }
        public async Task OnGetAsync(CancellationToken cancellationToken)
        {
            try
            {
                var userId = int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id) ? id : 0;
                IdentityApproved = await IdentityWorkGate.IsApprovedAsync(db, userId, cancellationToken);
                var ownProfile = await db.FreelancerProfiles.AsNoTracking().SingleOrDefaultAsync(x => x.UserId == userId, cancellationToken);
                WorkRole = ownProfile?.WorkRole ?? "client";
                WorkLocked = await JobAcceptanceRules.IsLockedAsync(db, userId, cancellationToken);
                if (userId != 0 && WorkRole is "freelancer" or "both")
                {
                    OpenTasks = await (from t in db.MarketplaceTasks.AsNoTracking()
                        join u in db.Users.AsNoTracking() on t.ClientId equals u.Id
                        where t.ClientId != userId && t.Status == "open" && !t.IsPrivate && (t.PostExpiresUtc == null || t.PostExpiresUtc > DateTime.UtcNow) orderby t.Id descending
                        select new MarketTasksModel.TaskItem(t, ((u.FirstName ?? "") + " " + (u.LastName ?? "")).Trim())).ToListAsync(cancellationToken);
                    MatchingJobIds = OpenTasks.Where(item => ServiceCatalog.Matches(ownProfile?.Service, ownProfile?.ServiceSpecialties, item.Task))
                        .Select(item => item.Task.Id.ToString(System.Globalization.CultureInfo.InvariantCulture)).ToArray();
                    Offers = await (from o in db.MarketplaceOffers.AsNoTracking()
                        join u in db.Users.AsNoTracking() on o.FreelancerId equals u.Id
                        join p in db.FreelancerProfiles.AsNoTracking() on u.Id equals p.UserId
                        where o.FreelancerId == userId
                        select new MarketTasksModel.OfferItem(o, ((u.FirstName ?? "") + " " + (u.LastName ?? "")).Trim(), p.Service)).ToListAsync(cancellationToken);
                    var offerTaskIds = Offers.Select(o => o.Offer.TaskId).Distinct().ToList();
                    OfferTaskTitles = await db.MarketplaceTasks.AsNoTracking().Where(t => offerTaskIds.Contains(t.Id)).ToDictionaryAsync(t => t.Id, t => t.Title, cancellationToken);
                }
                Providers = await (from profile in db.FreelancerProfiles.AsNoTracking()
                    join user in db.Users.AsNoTracking() on profile.UserId equals user.Id
                    where (profile.WorkRole == "freelancer" || profile.WorkRole == "both") && profile.UserId != userId
                        && profile.Service != "" && profile.Location != ""
                    orderby user.FirstName, user.Id
                    select new Provider(user.Id, ((user.FirstName ?? "") + " " + (user.LastName ?? "")).Trim(),
                        profile.Service, profile.Location, profile.Rate, profile.RateMaximum, profile.Availability, profile.ServiceSpecialties)).ToListAsync(cancellationToken);
                var active = await FreelancerAvailability.AssignmentsAsync(db, Providers.Select(p => p.Id).ToArray(), cancellationToken);
                Providers = Providers.Select(p => p with { Availability = FreelancerAvailability.Effective(p.Availability, active.GetValueOrDefault(p.Id) ?? []) }).ToList();
                try
                {
                    var reviews = await db.MarketplaceReviews.AsNoTracking().Where(r => !r.ByFreelancer).Select(r => new { r.FreelancerId, r.Rating }).ToListAsync(cancellationToken);
                    Ratings = reviews.GroupBy(r => r.FreelancerId).ToDictionary(g => g.Key, g => new RatingSummary(g.Average(r => r.Rating), g.Count()));
                }
                catch (MySqlConnector.MySqlException) { RatingsUnavailable = true; logger.LogWarning("Review ratings are unavailable"); }
            }
            catch (Exception ex) when (ex is MySqlConnector.MySqlException || ex is InvalidOperationException)
            {
                logger.LogError(ex, "Unable to load freelancer directory");
                DirectoryUnavailable = true;
            }
        }
    }
}
